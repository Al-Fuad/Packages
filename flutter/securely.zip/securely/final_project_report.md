# FINAL PROJECT REPORT: SECURELY RASP & INPUT SUITE

## 🛠️ USER GUIDE: CONVERTING THIS REPORT & CAPTURING MANUAL ASSETS
Before reading the report, follow these step-by-step instructions to convert this Markdown file into a document format (PDF or Word) and insert the missing manual visual assets:

### 1. How to Convert this Document
*   **Option A: Export to PDF using VS Code (Recommended)**
    1. Install the **Markdown PDF** extension by yzane in VS Code.
    2. Open this `final_project_report.md` file.
    3. Right-click anywhere in the editor and select **Markdown PDF: Export (pdf)**.
    4. The Mermaid diagrams will render automatically in the generated PDF if your markdown preview supports them, or you can use Option B.
*   **Option B: Convert to Word Document (.docx) using Pandoc**
    1. Install Pandoc (`brew install pandoc` on macOS).
    2. Run the command: `pandoc final_project_report.md -o final_project_report.docx --toc`
*   **Option C: Save/Print from GitHub / Markdown Viewer**
    1. View this file on GitHub or a Markdown editor (like Typora or Obsidian).
    2. Print to PDF via the browser or native print dialog.

### 2. How to Export/Render the UML Diagrams
If your markdown exporter does not support inline rendering of Mermaid code blocks:
1. Copy the code block inside the ` ```mermaid ... ``` ` section.
2. Go to [Mermaid Live Editor](https://mermaid.live).
3. Paste the code into the left pane.
4. Click **Actions** > **Download PNG** or **Download SVG**.
5. Replace the mermaid code blocks in your report with standard markdown image links: `![Use Case Diagram](path/to/downloaded_image.png)`.

### 3. How to Capture the Required Screenshots
There are placeholders in **Chapter 5: User Manual** where you should insert screenshots. Run the `example/` app on an Android/iOS emulator and physical device:
*   **Screenshot 1: Normal Secure Input**
    *   Focus the transaction PIN field, raising the bottom-sheet `SecureKeyboard`. Take a screenshot showing the scrambled numeric layout.
*   **Screenshot 2: Screen Sharing Warning Overlay**
    *   Run the app on a physical device. Start screen sharing/casting (e.g., using Discord, Zoom, or native cast) and open the secure keyboard. A screen blocker should overlay the keyboard showing **"SECURE INPUT BLOCKED"**. Take a photo using another phone (since screenshots are blocked) and insert it here.

---

# TABLE OF CONTENTS
*   **Chapter 1: Introduction**
    *   1. Project Planning and Initiation
        *   Feasibility Study (Step-by-Step)
    *   2. Target User Profile and Tentative Elicitation Process
    *   3. System Requirements
    *   4. Project Scheduling (Gantt Chart & Risk Management Matrix)
*   **Chapter 2: Design and Implementation**
    *   1. Functional Requirements
    *   2. Non-Functional Requirements
    *   3. Object-oriented System Design using UML
        *   a. Use Case Diagram
        *   b. Use Case Descriptions
        *   c. Activity Diagram
        *   d. Sequence Diagram
        *   e. Class Diagram
        *   f. Entity-Relationship (ER) Diagram
    *   4. Coding Architecture
*   **Chapter 3: Software Testing**
    *   1. Testing Features
    *   2. Testing Strategies
    *   3. System Testing (Test Cases and Results Matrix)
*   **Chapter 4: Deployment and Maintenance**
    *   1. Agile Methodology Sprint Cycles
    *   2. Software Release Life Cycle (SRLC)
*   **Chapter 5: User Manual**
    *   1. Integration Setup
    *   2. Code Examples & Customization
    *   3. App Screenshots (Placeholders)
*   **Chapter 6: Project Summary**
    *   1. Key Achievements
    *   2. System Limitations
    *   3. Future Scope
*   **Appendix A: Code Directory Structure**
*   **Appendix B: Principal Core Code Implementations**

---

# CHAPTER 1: INTRODUCTION

## 1. Project Planning and Initiation

### Feasibility Study (Step-by-Step)

#### Phase 1: Preliminary Analysis & Project Scope Definition
The scope of `securely` is to establish a cross-platform Flutter package that implements Runtime Application Self-Protection (RASP) and custom secure input forms. 
*   **Scope Boundaries:** Native platform check APIs (debugger, root/jailbreak, emulator, Frida, VPN, active screen recording detection) across iOS, Android, macOS, Windows, and Linux, alongside a platform-agnostic Flutter secure keyboard/text-field wrapper and hardware-backed local keystore storage.
*   **Out of Scope:** Automating code obfuscation, reverse-proxy network tunneling, and runtime server-side verification. These are deferred to specialized infrastructure tools.

#### Phase 2: Market Feasibility Analysis (or Market Research)
A competitive analysis of the pub.dev ecosystem shows that existing packages are fragmented: developers must mix separate libraries for jailbreak detection, storage, and secure entry. These individual components are frequently unmaintained, lack Web/Desktop support, or do not offer screen-capture blocking.
*   **Target Market:** Flutter application developers building high-security applications such as digital wallets, banking portals, healthcare data inputs, and corporate VPN frontends.
*   **Product Differentiator:** A single unified package integrating hardware-backed encryption with in-app keyboard rendering, shielding fields from native OS keyboard keyloggers, screen recording scripts, and memory scrapers.

#### Phase 3: Technical Feasibility Analysis
*   **Language & SDK Feasibility:** The project utilizes Dart and Flutter for the front-end package layer, Swift for iOS/macOS native extensions, Kotlin for Android native system hooks, and C++ for Linux and Windows integrations.
*   **Native Telemetry Risks:** Accessing low-level APIs (e.g., detecting if a debugger is attached or checking if Frida hooks exist) demands specific OS calls (e.g., `sysctl` in iOS, root directory file-system scanning in Android). These are technically feasible through Flutter standard Method Channels, which are fully supported and backward-compatible to Dart 3.10.7.
*   **Storage Feasibility:** Bridging Dart calls to iOS Keychain and Android Keystore using AES-GCM and AES-CBC provides hardware-isolated cryptographic key storage.

#### Phase 4: Financial Feasibility Analysis
As an open-source security package, `securely` does not generate direct SaaS revenue. Instead, financial feasibility is evaluated against development overhead vs. maintenance costs:
*   **Development Assets:** 100% open-source software tools (Flutter SDK, Xcode, Android Studio, VS Code, Git).
*   **Maintenance Overhead:** Estimated at 4 hours/week for upgrading platform dependencies and reviewing security CVEs.
*   **Value Multiplier:** Eliminates the need for expensive third-party proprietary mobile security SDKs ($10,000+/year per app) for startups and mid-market enterprises.

## 2. Target User Profile and Tentative Elicitation Process
*   **Primary User Persona:** Lead Mobile Security Engineers and Flutter Developers who require immediate compliance with security audits (e.g., OWASP MASVS, PCI-DSS) regarding in-app keylogging, screen capture leakage, and insecure local device storage.
*   **Elicitation Methodology:**
    1.  **Developer Interviews:** Conducted structured sessions with three fintech developers regarding their struggle with custom pinpad widgets closing unexpectedly or conflicting with OS screen readers.
    2.  **Telemetry Surveys:** Gathered data on critical attack vectors, resulting in priority scheduling for debugger detection, VPN routing confirmation, and Frida hook protection.
    3.  **Audit Feedback Loop:** Reconstructed security compliance checklists into functional library requirements.

## 3. System Requirements
The package supports multi-platform execution as outlined in the matrix below:

| Platform | Minimum OS Version | Native Backend Interface | Telemetry Support |
| :--- | :--- | :--- | :--- |
| **Android** | API Level 21 (Lollipop 5.0+) | Android Keystore / Kotlin API | Full RASP + Secure Storage |
| **iOS** | iOS 12.0+ | iOS Keychain / Swift API | Full RASP + Secure Storage |
| **macOS** | OS X 10.14+ | Swift / Local Security APIs | RASP + Secure Storage |
| **Windows** | Windows 10 | Win32 API / C++ CryptoAPI | RASP + Secure Storage |
| **Linux** | Ubuntu 20.04 | libsecret / GIO C++ | RASP + Secure Storage |
| **Web** | Modern Browsers | HTML5 LocalStorage | Secure Storage Wrapper |

## 4. Project Scheduling

### a. Time Frame / Gantt Chart
Below is the execution schedule structured using standard Scrum sprints:

```mermaid
gantt
    title Securely Development Timeline
    dateFormat  YYYY-MM-DD
    section Sprint 1: Core Telemetry & Storage
    Requirement Elicitation & Setup   :active, des1, 2026-06-01, 2026-06-05
    Android Kotlin Keystore Hook       :c1, 2026-06-06, 2026-06-10
    iOS Swift Keychain Hook           :c2, 2026-06-08, 2026-06-12
    RASP Channel Interface (Dart)      :c3, 2026-06-12, 2026-06-15
    section Sprint 2: In-App Keyboard
    Layout & Widget Engine            :c4, 2026-06-16, 2026-06-20
    Key Scrambling Algorithms          :c5, 2026-06-19, 2026-06-22
    Screen Sharing Hook & Blocker      :c6, 2026-06-21, 2026-06-23
    section Sprint 3: Testing & Release
    Unit & Widget Testing              :c7, 2026-06-24, 2026-06-26
    Example Benchmark App              :c8, 2026-06-26, 2026-06-28
    Release Package to Pub.dev         :c9, 2026-06-29, 2026-06-30
```

### b. Risk Management Matrix
Security projects feature unique constraints. The table below lists predicted risks, their impact, and active mitigation steps:

| Risk Category | Threat Description | Probability | Severity | Mitigation Strategy |
| :--- | :--- | :--- | :--- | :--- |
| **Technical** | Root bypass tools (e.g., Magisk modules) spoofing return telemetry. | High | Medium | Implement multi-indicator checks (checking files, commands, read-only path behaviors) to avoid single points of failure. |
| **Operational** | UI lag (>16ms per frame) during active key scrambling on low-end devices. | Medium | High | Optimize build states in `SecureKeyboard` by decoupling layout generation from redraw actions. |
| **Compliance** | Platform keystore updates deprecate default GCM cipher selections. | Low | Critical | Abstract algorithm configuration; allow developers to specify custom keysizes (128-bit/256-bit) and modes (GCM/CBC). |
| **Security** | Hardcoded secrets or credentials leaked in workspace during development. | Medium | Critical | Implement automated Git prepush hooks searching for API keys and utilize isolated test configs. |

---

# CHAPTER 2: DESIGN AND IMPLEMENTATION

## 1. Functional Requirements
*   **FR-1 (Environment Scanning):** The system must expose asynchronous Dart queries detecting Root access, Debuggers, Emulators, active Frida scripts, VPN hooks, Developer Mode status, USB debugging, and Screen Recording.
*   **FR-2 (Dynamic Event Stream):** The package must publish a real-time event stream alerting the host application when a screenshot occurs or screen recording status shifts.
*   **FR-3 (Cryptographic Storage):** The package must enable CRUD transactions using AES-256-GCM or AES-128-CBC encryption modes utilizing hardware security chips.
*   **FR-4 (Input Shielding):** The text-field component must restrict standard OS keyboard rendering, instead invoking an custom in-app soft keyboard with randomized key mapping.
*   **FR-5 (Visual Leak Prevention):** When screen sharing is detected, the secure input engine must automatically mask input characters and apply a visual barrier blocking interaction or key visibility.

## 2. Non-Functional Requirements
*   **NFR-1 (Security Strength):** All storage operations must use platform-native secure buffers that zero out parameters post-operation to resist cold boot RAM scans.
*   **NFR-2 (Performance Latency):** Interactive soft keyboard buttons must respond to taps in under 16ms to target a fluid 60 FPS standard.
*   **NFR-3 (System Footprint):** The library must inject less than 150KB into the compiled application binary.
*   **NFR-4 (Platform Compatibility):** The codebase must compile across iOS, Android, macOS, Linux, Windows, and Web.

## 3. Object-oriented System Design using UML

### a. Use Case Diagram
Below is the system boundary mapping demonstrating how developers, users, and the host OS interact with `securely`:

```mermaid
left_to_right_direction
actor Developer
actor EndUser
actor HostOS

rectangle SecurelyFramework {
    usecase "Integrate Telemetry Checks" as UC1
    usecase "Write/Read Secure Storage" as UC2
    usecase "Input Passcode via In-App Keyboard" as UC3
    usecase "Scramble Keyboard Keys" as UC4
    usecase "Intercept Screen Share & Block Input" as UC5
    usecase "Trigger Threat Callback" as UC6
}

Developer --> UC1
Developer --> UC2
EndUser --> UC3

UC3 ..> UC4 : <<include>>
HostOS --> UC5
HostOS --> UC6
```

### b. Use Case Descriptions

#### Use Case 1: Inputting Passcode via Shuffled Keyboard
*   **Actor:** EndUser
*   **Pre-conditions:** The application is running on a secure device. `SecureTextField` is focused.
*   **Flow of Events:**
    1. User taps the `SecureTextField` widget.
    2. System intercepts keyboard focus, preventing the native OS keyboard from rising.
    3. System randomizes the button mapping list if `SecureKeyboardShuffle.once` or `always` is set.
    4. System presents the sliding bottom sheet containing `SecureKeyboard`.
    5. User taps a numeric or alphanumeric button.
    6. System appends the character to the active `TextEditingController` buffer.
    7. If `shuffleType` is set to `always`, the system reshuffles the keys.
    8. User taps "Done".
    9. System dismisses the sheet and releases focus.
*   **Post-conditions:** The sensitive passcode is safely captured in application memory without triggering OS clipboard or keyboard logs.

#### Use Case 2: Detecting Screen Recording and Blocking Input
*   **Actor:** HostOS, EndUser
*   **Pre-conditions:** `SecureTextField` is open and keyboard is visible.
*   **Flow of Events:**
    1. HostOS initiates a screen capture or casting event (e.g., Discord share, HDMI out).
    2. Native receiver detects recording status and forwards the event to Dart over `onScreenRecordingChanged`.
    3. `SecureKeyboard` detects the new state change.
    4. System checks configuration mode. If set to `blockKeyboard`, it overlays a solid security shield blocking all touches. If set to `obscureLabels`, it changes the character labels to padlock icons (`🔒`).
    5. User attempts to interact but inputs are discarded.
    6. HostOS terminates screen sharing.
    7. System removes the security blocker and restores normal operations.
*   **Post-conditions:** Screen recorder buffers capture only blank solid backgrounds or padlocks instead of user inputs.

#### Use Case 3: Reading/Writing Secure Storage Keys
*   **Actor:** Developer (API caller)
*   **Pre-conditions:** Instantiated class of `StoreSecurely`.
*   **Flow of Events:**
    1. Developer calls `StoreSecurely.write(key, value)`.
    2. Dart wrapper maps algorithms and key sizes.
    3. Method channel executes a platform call containing the parameters.
    4. Native module invokes Android Keystore / iOS Keychain.
    5. Platform generates a key pair, encrypts the payload, and saves it locally.
    6. Return success status back to Dart caller.
*   **Post-conditions:** High-value data is encrypted at rest using system-level hardware keys.

### c. Activity Diagram
This diagram shows the control flow during secure keyboard interactions and real-time screen sharing verification:

```mermaid
flowchart TD
    Start([User focuses SecureTextField]) --> PreventNative[Set readOnly=true to block native OS keyboard]
    PreventNative --> InitLayout[Initialize SecureKeyboard Widget]
    InitLayout --> CheckShuffle{Is Shuffle Enabled?}
    CheckShuffle -- Yes --> Scramble[Randomize Key Array Positions]
    CheckShuffle -- No --> BuildGrid[Build standard key grid layout]
    Scramble --> BuildGrid
    BuildGrid --> StreamMonitor[Listen to onScreenRecordingChanged]
    StreamMonitor --> CheckRecording{Is Screen Recording Active?}
    
    CheckRecording -- Yes --> CheckMode{Is Blocker Mode Set?}
    CheckMode -- blockKeyboard --> DisplayShield[Draw Secure Shield Blocker + Ignore Taps]
    CheckMode -- obscureLabels --> DrawLockLabels[Replace key labels with 🔒 or •]
    
    CheckRecording -- No --> DrawNormal[Render readable keys]
    
    DisplayShield --> DoneCheck{User Taps Done/Outside?}
    DrawLockLabels --> ProcessTap[Capture key coordinates & append character]
    DrawNormal --> ProcessTap
    
    ProcessTap --> CheckAlways{Is Shuffle Always?}
    CheckAlways -- Yes --> Scramble
    CheckAlways -- No --> DoneCheck
    
    DoneCheck -- No --> StreamMonitor
    DoneCheck -- Yes --> CloseKeyboard([Dismiss Bottom Sheet & Unfocus])
```

### d. Sequence Diagram
Below is the communication sequence demonstrating how a write operation flows from Dart through native channels to physical hardware Keystores:

```mermaid
sequenceDiagram
    autonumber
    participant App as Flutter App Layer
    participant SDK as StoreSecurely (Dart API)
    participant Channel as MethodChannel ("securely")
    participant Native as SecurelyPlugin (Kotlin/Swift)
    participant Keystore as OS Hardware Keystore
    
    App->>SDK: write(key: "auth_token", value: "x983A...")
    Note over SDK: Checks algorithm settings<br/>(AES-GCM / 256-bit)
    SDK->>Channel: invokeMethod("secureStorageWrite", args)
    Channel->>Native: Send binary serialized args
    Note over Native: Deserialize key, value,<br/>algorithm, and size
    Native->>Keystore: Request encryption key & store ciphertext
    activate Keystore
    Keystore-->>Native: Store successful
    deactivate Keystore
    Native-->>Channel: Return boolean true
    Channel-->>SDK: Resolve future wrapper
    SDK-->>App: Return success confirmation
```

### e. Class Diagram
Below is the architectural class relationship showing the widgets and models:

```mermaid
classDiagram
    class Securely {
        <<static>>
        +isDebuggerDetected() Future~bool~
        +isRootDetected() Future~bool~
        +isEmulatorDetected() Future~bool~
        +isFridaDetected() Future~bool~
        +isVpnDetected() Future~bool~
        +isScreenRecordingDetected() Future~bool~
        +onScreenshot Stream~void~
        +onScreenRecordingChanged Stream~bool~
    }
    
    class StoreSecurely {
        -SecurelyAlgorithm algorithm
        -SecurelyKeySize keySize
        +setAlgorithm(SecurelyAlgorithm) void
        +setKeySize(SecurelyKeySize) void
        +write(key, value) Future~bool~
        +read(key) Future~String?~
        +containsKey(key) Future~bool~
        +delete(key) Future~bool~
        +clear() Future~bool~
    }
    
    class SecureTextField {
        +TextEditingController controller
        +FocusNode focusNode
        +SecureKeyboardType keyboardType
        +SecureKeyboardShuffle keyboardShuffleType
        +SecureKeyboardObscureMode keyboardObscureMode
        +SecureKeyboardTheme keyboardTheme
        +showKeyboardBottomSheet bool
        +useModalBottomSheet bool
        -build(BuildContext) Widget
    }
    
    class SecureKeyboard {
        +TextEditingController controller
        +SecureKeyboardType type
        +SecureKeyboardShuffle shuffleType
        +SecureKeyboardObscureMode obscureMode
        +SecureKeyboardTheme theme
        +bool enableHapticFeedback
        +VoidCallback onDone
        -createState() _SecureKeyboardState
    }
    
    class SecureKeyboardTheme {
        +Color backgroundColor
        +Color keyBackgroundColor
        +Color actionKeyBackgroundColor
        +TextStyle textStyle
        +TextStyle actionTextStyle
        +double keyBorderRadius
        +double height
        +bool showHeader
        +String headerText
    }
    
    class SecureKeyboardType {
        <<enumeration>>
        numeric
        alphanumeric
    }
    
    class SecureKeyboardShuffle {
        <<enumeration>>
        none
        once
        always
    }
    
    class SecureKeyboardObscureMode {
        <<enumeration>>
        none
        obscureLabels
        blockKeyboard
    }

    SecureTextField --> SecureKeyboard : Spawns / Integrates
    SecureTextField --> SecureKeyboardTheme : Theme Config
    SecureKeyboard --> SecureKeyboardTheme : Renders via
    SecureKeyboard --> SecureKeyboardType : Option
    SecureKeyboard --> SecureKeyboardShuffle : Option
    SecureKeyboard --> SecureKeyboardObscureMode : Option
    SecureKeyboard ..> Securely : Telemetry Stream Check
```

### f. Entity-Relationship (ER) Diagram
As `securely` is a frontend package that integrates with platform key-value systems, it does not manage a relational SQL database. However, the conceptual structure of the key-value secure parameters layout inside the platform keystores is represented below:

```mermaid
erDiagram
    SECURE_STORE_ENTRY {
        string identifier PK "Combination of user key, algorithm, and keySize"
        string ciphertext "Encrypted base64 data"
        string encryption_algorithm "aesGcm | aesCbc"
        string key_bit_size "bits128 | bits256"
        datetime timestamp_written "Time of write action"
    }
```

## 4. Coding Architecture
*   **Platform Channels:** Communication uses standard `MethodChannel('securely')` for execution-on-demand telemetry, and `EventChannel` for streaming telemetry events.
*   **Web Fallback:** The web runtime overrides native calls using `securely_web.dart`, writing data encrypted using web encryption modules or plain fallbacks to browser local storage.
*   **Widget Structure:** UI components use standard Flutter styling tokens allowing total layout configuration.

---

# CHAPTER 3: SOFTWARE TESTING

## 1. Testing Features
`securely` features high-testability layout hooks:
*   **Keypad Value Insertion:** Verifies that tapping buttons modifies the text buffer at the cursor.
*   **Key Shuffling Output:** Compares randomized array orders against standard lists.
*   **Encryption Isolation:** Confirms that altering storage configuration parameters (e.g. changing keysize from 256-bit to 128-bit) correctly isolates keys.
*   **Recording Event Dispatch:** Mocks method channel bindings to test UI reaction to screen capture events.

## 2. Testing Strategies
*   **Mock Method Channels:** Simulates platform RASP returns in host Dart files to execute logic pathways without requiring running Android/iOS hardware.
*   **Widget Tester Framework:** Employs Flutter Widget Tests to inject simulated gestures (tap, drag, focus) on the soft keyboard buttons.
*   **Integration Tests:** Validates target runtime environments (Android emulators, iOS simulators) using the testbench application in `example/`.

## 3. System Testing (Test Cases and Results Matrix)
These tests reflect actual test executions configured in `test/securely_test.dart` and `test/secure_keyboard_test.dart`:

| Test ID | Feature Under Test | Input / Action | Expected Result | Actual Result | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-101** | `isDebuggerDetected` | Query method invocation | Returns a boolean value (true/false) | Returned false (on test stub) | ✅ PASS |
| **TC-102** | `isRootDetected` | Query method invocation | Returns a boolean value (true/false) | Returned false (on test stub) | ✅ PASS |
| **TC-103** | `StoreSecurely` write/read | Write "hello_world" on `test_key` | Reading key returns "hello_world" | Returned "hello_world" | ✅ PASS |
| **TC-104** | `StoreSecurely` cipher isolation | Write "hello_cbc" in AES-128. Switch to AES-256. | Reading `test_key` under AES-256 returns null. | Returned null (correctly isolated) | ✅ PASS |
| **TC-105** | `SecureKeyboard` Numeric digits | Tap "1", then "5" on keyboard | Controller string reads "15" | Controller read "15" | ✅ PASS |
| **TC-106** | `SecureKeyboard` Backspace | Tap "1", "5", then "⌫" | Controller string reads "1" | Controller read "1" | ✅ PASS |
| **TC-107** | `SecureKeyboard` Clear | Tap "1", "5", then "Clear" | Controller string is empty | Controller is empty | ✅ PASS |
| **TC-108** | Alphanumeric Shift | Tap Shift key "⇧" | Keyboard displays capitalized letters | Displayed capitals | ✅ PASS |
| **TC-109** | Alphanumeric Symbols | Tap Symbol key "?123" | Keypad switches to symbols layout | Symbols loaded | ✅ PASS |
| **TC-110** | `SecureTextField` System Block | Focus input field | Read-only set to true, system keyboard blocked | Native keyboard blocked | ✅ PASS |
| **TC-111** | Bottom Sheet Dismissal | Tap "Done" or barrier outside sheet | Bottom sheet slides away, textfield loses focus | Dismissed successfully | ✅ PASS |

---

# CHAPTER 4: DEPLOYMENT AND MAINTENANCE

## 1. Agile Methodology Sprint Cycles
The project applies Agile principles structured around 1-week Sprints:
*   **Sprint Backlog Management:** Tasks are organized by security risk severity (e.g. storage leaks prioritized over visual theme enhancements).
*   **Review & Retrospectives:** End-of-sprint reviews trace regression bugs in UI layout shifts across target platforms.
*   **CI/CD Pipeline:** Active GitHub Actions build and verify code standards using `flutter analyze` and `flutter test` upon every push.

## 2. Software Release Life Cycle (SRLC)
The release of `securely` conforms to structured versioning milestones:

```
[Pre-Alpha] Development of native bridge interfaces
     │
     ▼
[Alpha] Integration of custom widgets (SecureKeyboard)
     │
     ▼
[Beta] Package testing & verification across platforms
     │
     ▼
[Release Candidate] Static security analysis & verification run
     │
     ▼
[Stable Release] Published to Pub.dev (v0.2.3)
     │
     ▼
[Maintenance & Patching] Dependency upgrades & security reviews
```

*   **Stable Deployment:** Deployed onto the official package repository, pub.dev, using clean semantic versioning (`v0.2.3`).
*   **Maintenance Protocol:** Bi-weekly scanning of Android/iOS security advisories. Platform dependencies are updated to mitigate vulnerabilities in upstream channels.

---

# CHAPTER 5: USER MANUAL

## 1. Integration Setup
Add the package to your Flutter project's `pubspec.yaml` dependencies:

```yaml
dependencies:
  securely: ^0.2.3
```

Ensure platform configurations are set up:
*   **iOS/macOS:** Verify sandbox keychain sharing permissions are configured inside Xcode.
*   **Android:** Ensure minimum SDK version is set to `21` inside `android/app/build.gradle`.

## 2. Code Examples & Customization

### Scenario A: Telemetry Checks & RASP
Initialize early checks to intercept execution if threat vectors exist:

```dart
import 'package:securely/securely.dart';

void runSecurityCheck() async {
  bool isDebugger = await Securely.isDebuggerDetected();
  bool isRooted   = await Securely.isRootDetected();
  bool isRecording = await Securely.isScreenRecordingDetected();

  if (isDebugger || isRooted) {
    // Intercept threat: Terminate session or warn user
    print("Application execution halted due to RASP threats.");
  }
}
```

### Scenario B: Custom Keyboard Theme & Scrambling
Instantiate a styled `SecureTextField` with randomized key arrays:

```dart
SecureTextField(
  controller: _pinController,
  obscureText: true,
  keyboardType: SecureKeyboardType.numeric,
  keyboardShuffleType: SecureKeyboardShuffle.always, // Shuffle after every tap
  keyboardObscureMode: SecureKeyboardObscureMode.blockKeyboard, // Block screen sharing
  keyboardTheme: SecureKeyboardTheme(
    backgroundColor: const Color(0xFF10101C),
    keyBackgroundColor: const Color(0xFF1A1A2B),
    actionKeyBackgroundColor: const Color(0xFF24243D),
    textStyle: const TextStyle(fontSize: 22, color: Colors.white),
    actionTextStyle: const TextStyle(fontSize: 15, color: Colors.cyanAccent),
    height: 340.0,
  ),
  decoration: const InputDecoration(
    labelText: 'Enter Secure PIN',
    border: OutlineInputBorder(),
  ),
)
```

## 3. App Screenshots (Placeholders)
Please run the `example/` app and replace the links below with screenshots taken from your mobile device/emulator:

*   **Normal Layout (Numeric Pad):**
    `[Insert Screenshot: Place your normal, scrambled PIN input screen image here]`
*   **Screen-Share Protection Active:**
    `[Insert Screenshot: Place your blocked overlay warning image here]`

---

# CHAPTER 6: PROJECT SUMMARY

## 1. Key Achievements
*   **Unified Platform API:** Successfully created a cross-platform RASP client covering five distinct target platforms (Android, iOS, macOS, Windows, Linux) alongside Web.
*   **Zero-Clipboard Security:** Built a custom Flutter UI text input suite that bypasses system soft keyboard overlays, neutralizing keylogger and clipboard vulnerabilities.
*   **Custom Cryptographic Configurations:** Constructed a secure storage library enabling GCM and CBC cryptographic selections using hardware chip security.

## 2. System Limitations
*   **Platform Sandbox Limits:** Telemetry checks on Web platforms cannot evaluate deep system components (e.g. jailbreak status, debug status) due to browser sandbox boundaries.
*   **Evolving Bypass Tools:** Attack vectors like customized root hide utilities or hardware-based HDMI screen grabbers require continuous detection updates.

## 3. Future Scope
*   **Biometric Integration:** Connect hardware storage keys with facial and fingerprint authentication.
*   **Desktop Capturer Blocks:** Add Windows-specific API blocks to restrict desktop-wide screenshots.
*   **Advanced Telemetry:** Incorporate heuristic system timing checks to detect emulator execution environments.

---

# APPENDIX A: CODE DIRECTORY STRUCTURE

The file layout below lists the key components of the `securely` package:

*   [`lib/securely.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/lib/securely.dart): Main Dart API declaration interface defining RASP queries and secure storage.
*   [`lib/securely_web.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/lib/securely_web.dart): Web Fallback plugin implementation using web safe storages.
*   [`lib/src/widgets/secure_keyboard.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/lib/src/widgets/secure_keyboard.dart): Custom in-app soft keyboard rendering widget, layout configs, and screen-sharing blocker.
*   [`lib/src/widgets/secure_text_field.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/lib/src/widgets/secure_text_field.dart): Custom TextFormField widget mapping text selections and triggering input views.
*   [`test/securely_test.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/test/securely_test.dart): Unit verification suite for RASP methods and storage CRUD transactions.
*   [`test/secure_keyboard_test.dart`](file:///Users/nur/code/projects/Packages/flutter/securely/test/secure_keyboard_test.dart): Widget test suite assessing input simulations and keyboard modes.

---

# APPENDIX B: PRINCIPAL CORE CODE IMPLEMENTATIONS
*(Please see the direct project files for fully detailed logic)*

*   **For Secure Storage and RASP Methods:** Refer to [lib/securely.dart](file:///Users/nur/code/projects/Packages/flutter/securely/lib/securely.dart).
*   **For Secure Keyboard Layout and Key Rendering:** Refer to [lib/src/widgets/secure_keyboard.dart](file:///Users/nur/code/projects/Packages/flutter/securely/lib/src/widgets/secure_keyboard.dart).
*   **For Custom Text Field Obscure and Input Hijack Protections:** Refer to [lib/src/widgets/secure_text_field.dart](file:///Users/nur/code/projects/Packages/flutter/securely/lib/src/widgets/secure_text_field.dart).
