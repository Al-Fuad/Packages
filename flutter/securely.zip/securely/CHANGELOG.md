# Changelog

All notable changes to this project will be documented in this file.

The format is based on **Keep a Changelog**,  
and this project follows **Semantic Versioning**.

## [0.2.3] - Change homepage URL to repo URL

### Changed
- **Homepage URL**: homepage URL in `pubspec.yaml` is now repository URL.

---

## [0.2.2] - Fix Example Tests and change repo path

### Fixed
- **Example Tests**: Updated example integration and widget tests to import from the correct package path.

### Changed
- **Package Path**: Update repository path https://github.com/Al-Fuad/Securely to https://github.com/Al-Fuad/Packages/tree/main/flutter/securely.

---

## [0.2.1] - Swift Package Manager Support

### Added
- **Swift Package Manager Support**: Added support for integrating the native iOS/macOS plugin

---

## [0.2.0] - Web Support and Cross-Platform Parity

### Added
- **Web Support**: Added a dummy web implementation that returns `false` for all checks.
 
---

## [0.1.0] - Cross-Platform Parity

### Added
- **Desktop Support**: Added detection capabilities for Windows, macOS, and Linux.
  - Debugger detection via native system APIs.
  - Virtualization/Hypervisor detection for desktop environments.
  - Privilege detection (Root/Administrator check).

---

## [0.0.4] - Fix Path

### Fixed
- **Fix Path**: Resolved incorrect file pathing issues within android project.

## [0.0.3] - Change Organization

### Changed
- **Organization Rename**: Updated package name and organization identifiers to `me.alfuad`.

---

## [0.0.2] - Dart Documentation

### Added
- **Full API Documentation**: Added dartdoc comments to 100% of the public API to improve developer experience and pub.dev score.

---

## [0.0.1] - Core Runtime Detection Layer

### Added
- **Emulator Detection**
  - Detects Android emulators and iOS simulators
  - Identifies virtualized environments used for analysis
- **Frida Basic Detection**
  - Detects common Frida server/process indicators
  - Checks for known Frida-related artifacts
- **Root Detection (Android)**
  - Detects rooted devices using multiple indicators
  - Checks for su binaries and dangerous system properties
- **Jailbreak Detection (iOS)**
  - Detects jailbroken environments using filesystem and runtime checks
- **Debugger Detection**
  - Detects attached debuggers at runtime
  - Prevents debugging-based reverse engineering

### Architecture
- Platform-specific detection logic (Android / iOS)
- Modular detection system for easy extension
- Runtime-first security checks (executed during app lifecycle)

### Notes
- Detection modules are implemented and tested individually
- Response handling is intentionally minimal at this stage

---

## [Unreleased]

### Planned
- **Unified Security Result**
  - Centralized security state aggregation
  - Single source of truth for all detection outcomes
- **Simple Runtime Response**
  - Immediate action handling on threat detection
  - Configurable responses (log, warn, restrict, terminate)
- **Secure Storage**
  - Encrypted local storage for sensitive data
  - Key management and secure access patterns
- Advanced Frida & Hook Detection
- Memory Tampering Detection
- Security Policy Engine
- Developer Configuration API
